package model;

public class Normal extends Item {

	public Normal(String itemName, int itemPoint) {
		super(itemName, itemPoint);
	}
	
}
