package model;

public class Potion extends Item {

	public Potion(String itemName, int itemPoint) {
		super(itemName, itemPoint);
	}

}
